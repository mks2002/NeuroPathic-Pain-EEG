# safe_multi_channel_pipeline_no_leakage.py
import os
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.feature_selection import mutual_info_classif, f_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

# ---------------- CONFIG ----------------
BASE_MERGED_DIR = Path("Merged_Features_AllMethods")   # per-channel merged files
OUT_MAIN_DIR = Path("ML_Model_Results_NoLeak")
OUT_MAIN_DIR.mkdir(exist_ok=True, parents=True)

FEATURE_COUNTS = [2, 3, 4, 5]   # number of top features to take from each channel
RANDOM_STATE = 42

# models to evaluate (you can adjust)
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

MODELS = {
    "LogisticRegression": LogisticRegression(max_iter=2000, solver="liblinear", random_state=RANDOM_STATE),
    "RandomForest": RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE),
    "XGBoost": XGBClassifier(n_estimators=200, use_label_encoder=False, eval_metric="mlogloss", random_state=RANDOM_STATE),
    "LGBM": LGBMClassifier(n_estimators=200, random_state=RANDOM_STATE),
    "SVM": SVC(kernel="rbf", probability=True, random_state=RANDOM_STATE),
    "KNN": KNeighborsClassifier(n_neighbors=5),
    "NaiveBayes": GaussianNB(),
    "MLP": MLPClassifier(max_iter=500, random_state=RANDOM_STATE),
}

# ---------------- HELPERS ----------------
def safe_subject_labels_from_channel_files(channel_files):
    """
    Build mapping subj_id -> label (mode over rows). Warn if inconsistencies.
    Returns dict{subj: label} and list of skipped subjects (no label).
    """
    subj_labels = {}
    conflicts = {}
    for f in channel_files:
        df = pd.read_csv(f, usecols=["subj_id", "label"])
        for sid, grp in df.groupby("subj_id"):
            vals = grp["label"].dropna().unique().tolist()
            if len(vals) == 0:
                continue
            if sid not in subj_labels:
                subj_labels[sid] = vals[0] if len(vals)==1 else pd.Series(grp["label"]).mode().iloc[0]
            else:
                # if different, record conflict and take mode across seen + new
                if subj_labels[sid] not in vals:
                    conflicts.setdefault(sid, set()).update(vals + [subj_labels[sid]])
                    # resolve: take mode from concatenated
                    all_vals = list(vals) + [subj_labels[sid]]
                    subj_labels[sid] = pd.Series(all_vals).mode().iloc[0]
    return subj_labels, list(conflicts.keys())

def subject_stratified_split_from_map(subj_label_map, test_size=0.2, random_state=42):
    """Given subj->label map, return train_subjs, test_subjs stratified by label (subject-level)."""
    sids = np.array(list(subj_label_map.keys()))
    labs = np.array([subj_label_map[s] for s in sids])
    le = LabelEncoder()
    y_enc = le.fit_transform(labs)
    train_sids, test_sids = train_test_split(sids, test_size=test_size, stratify=y_enc, random_state=random_state)
    return set(train_sids.tolist()), set(test_sids.tolist()), le

def compute_channel_feature_scores(X_df, y_series):
    """
    Compute combined simple scores for features on given DataFrame X_df (features only)
    using multiple methods (ANOVA F, mutual info, RF feature importance, logistic coef).
    Returns DataFrame with normalized scores.
    """
    X = X_df.values
    y = y_series.values
    feats = list(X_df.columns)

    # Filter out constant columns
    nun = X_df.nunique()
    const_cols = nun[nun <= 1].index.tolist()
    if len(const_cols) > 0:
        X_df = X_df.drop(columns=const_cols)
        feats = list(X_df.columns)
        X = X_df.values

    scores = {}
    # ANOVA F
    try:
        fvals = f_classif(X, y)[0]
        scores["anova"] = (fvals - np.nanmin(fvals)) / (np.nanmax(fvals) - np.nanmin(fvals) + 1e-12)
    except Exception:
        scores["anova"] = np.zeros(len(feats))

    # Mutual information
    try:
        mi = mutual_info_classif(X, y, random_state=RANDOM_STATE)
        scores["mi"] = (mi - np.nanmin(mi)) / (np.nanmax(mi) - np.nanmin(mi) + 1e-12)
    except Exception:
        scores["mi"] = np.zeros(len(feats))

    # Random forest
    try:
        rf = RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1)
        rf.fit(X, y)
        rfimp = rf.feature_importances_
        scores["rf"] = (rfimp - np.nanmin(rfimp)) / (np.nanmax(rfimp) - np.nanmin(rfimp) + 1e-12)
    except Exception:
        scores["rf"] = np.zeros(len(feats))

    # Logistic absolute coef (after scaling)
    try:
        from sklearn.preprocessing import StandardScaler
        sc = StandardScaler()
        Xs = sc.fit_transform(X)
        log = LogisticRegression(max_iter=2000, solver="liblinear")
        log.fit(Xs, y)
        coef = np.abs(log.coef_).mean(axis=0)
        scores["logreg"] = (coef - np.nanmin(coef)) / (np.nanmax(coef) - np.nanmin(coef) + 1e-12)
    except Exception:
        scores["logreg"] = np.zeros(len(feats))

    # combine
    score_df = pd.DataFrame({
        "feature": feats,
        "anova": scores["anova"],
        "mi": scores["mi"],
        "rf": scores["rf"],
        "logreg": scores["logreg"]
    })
    score_df["avg_score"] = score_df[["anova","mi","rf","logreg"]].mean(axis=1)
    score_df = score_df.sort_values("avg_score", ascending=False).reset_index(drop=True)
    return score_df

def plot_and_save_cm(y_true, y_pred, labels, out_png, title):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(5,4))
    sns.heatmap(cm, annot=True, fmt="d", xticklabels=labels, yticklabels=labels, cmap="Blues")
    plt.title(title)
    plt.xlabel("Predicted"); plt.ylabel("True")
    plt.tight_layout()
    plt.savefig(out_png); plt.close()

# ---------------- MAIN SAFE PIPELINE ----------------
# 1) Collect channel merged files
channel_files = sorted(BASE_MERGED_DIR.glob("*_merged.csv"))
if len(channel_files) == 0:
    raise SystemExit("No *_merged.csv files found in Merged_Features_AllMethods")

channels = [f.stem.replace("_merged","") for f in channel_files]
print("Channels found:", channels)

# 2) Build subj -> label mapping from available channel files (robust)
subj_label_map, conflicts = safe_subject_labels_from_channel_files(channel_files)
print(f"Subjects with labels found: {len(subj_label_map)}  | conflicts: {conflicts}")

# If too few subjects with labels, abort
if len(subj_label_map) < 4:
    raise SystemExit("Too few labeled subjects to do stratified split. Provide labels.")

# 3) Split subjects into train/test (subject-level stratify)
train_subjs, test_subjs, subj_label_encoder = subject_stratified_split_from_map(subj_label_map, test_size=0.2, random_state=RANDOM_STATE)
print(f"Train subjects: {len(train_subjs)}  Test subjects: {len(test_subjs)}")

# Save subject splits
pd.DataFrame({"train_subj": sorted(list(train_subjs))}).to_csv(OUT_MAIN_DIR/"train_subjects.csv", index=False)
pd.DataFrame({"test_subj": sorted(list(test_subjs))}).to_csv(OUT_MAIN_DIR/"test_subjects.csv", index=False)

# 4) For each channel compute top features using ONLY training-subject rows
per_channel_top_feats = {}   # channel -> ordered list of features (ranked)
for ch in channels:
    ch_file = BASE_MERGED_DIR / f"{ch}_merged.csv"
    if not ch_file.exists():
        print("⚠️ Missing merged for", ch); continue
    df = pd.read_csv(ch_file)
    # ensure required columns exist
    if not set(["subj_id","label","window_idx"]).issubset(df.columns):
        print("⚠️ Missing subj_id/label/window_idx in", ch_file); continue

    # keep only rows for training subjects to compute ranking
    train_rows = df[df["subj_id"].isin(train_subjs)].copy()
    # drop rows with missing labels
    train_rows = train_rows[~train_rows["label"].isna()]

    # get subject-level labels for train rows (should be consistent)
    # Prepare y vector (subject-level label repeated per window)
    if train_rows.shape[0] == 0:
        print("⚠️ No training rows for channel:", ch); per_channel_top_feats[ch] = []; continue

    y = train_rows["label"].astype(str)
    X_df = train_rows.drop(columns=["subj_id","window_idx","label"]).select_dtypes(include=[np.number]).copy()
    if X_df.shape[1] == 0:
        print("⚠️ No numeric feature columns in", ch); per_channel_top_feats[ch] = []; continue

    # compute ranking on training rows
    try:
        score_df = compute_channel_feature_scores(X_df, y)
        ranked_features = score_df["feature"].tolist()
        per_channel_top_feats[ch] = ranked_features
        # save ranking for reference
        score_df.to_csv(OUT_MAIN_DIR / f"{ch}_ranking_train_only.csv", index=False)
        print(f"{ch}: computed ranking on train rows -> {len(ranked_features)} features")
    except Exception as e:
        print("❌ Error computing ranking for", ch, e)
        per_channel_top_feats[ch] = []

# 5) For each n_feats build merged_global using top n_feats per channel (selected by training)
summary_best = []

for n_feats in FEATURE_COUNTS:
    print("\n" + "="*60)
    print(f"Processing with top {n_feats} features per channel (train-only ranking)")
    run_out = OUT_MAIN_DIR / f"{n_feats}_best_per_channel"
    run_out.mkdir(exist_ok=True, parents=True)

    # Build list of filtered per-channel dataframes (columns trimmed to top n_feats)
    trimmed_dfs = []
    valid_channels = []
    for ch in channels:
        ch_file = BASE_MERGED_DIR / f"{ch}_merged.csv"
        if not ch_file.exists():
            continue
        df = pd.read_csv(ch_file)
        ranked = per_channel_top_feats.get(ch, [])
        if not ranked:
            print(f"Skipping {ch} (no ranking)")
            continue
        selected = [f for f in ranked[:n_feats] if f in df.columns]
        if len(selected) == 0:
            print(f"Skipping {ch} (no selected features found in df columns)")
            continue
        keep = ["subj_id","window_idx","label"] + selected
        trimmed = df.loc[:, [c for c in keep if c in df.columns]].copy()
        # rename selected feature columns to include channel suffix if not already included
        # (This avoids accidental collisions if two channels used same generic names)
        rename_map = {f: (f"{f}_{ch}" if not f.endswith(f"_{ch}") else f) for f in selected}
        trimmed = trimmed.rename(columns=rename_map)
        trimmed_dfs.append(trimmed)
        valid_channels.append(ch)

    if len(trimmed_dfs) == 0:
        print("No channel data available for this n_feats. Skipping.")
        continue

    # Merge horizontally on subj_id, window_idx, label using inner join to ensure aligned windows across channels
    merged_global = trimmed_dfs[0]
    for d in trimmed_dfs[1:]:
        merged_global = pd.merge(merged_global, d, on=["subj_id","window_idx","label"], how="inner")

    print("Merged global shape (rows x cols):", merged_global.shape)
    merged_global.to_csv(run_out/"merged_global.csv", index=False)

    # Clean NaN/Inf
    # compute column means (numeric)
    feat_cols = [c for c in merged_global.columns if c not in ("subj_id","window_idx","label")]
    Xmat = merged_global[feat_cols].values.astype(float)
    # Replace inf and nan
    Xmat = np.nan_to_num(Xmat, nan=np.nan)
    col_means = np.nanmean(Xmat, axis=0)
    col_means = np.where(np.isnan(col_means), 0.0, col_means)
    inds = np.where(np.isnan(Xmat))
    if inds[0].size > 0:
        Xmat[inds] = np.take(col_means, inds[1])
    Xmat = np.nan_to_num(Xmat, posinf=0.0, neginf=0.0)
    merged_global.loc[:, feat_cols] = Xmat

    # Build train/test splits by subject (use the previously computed train_subjs/test_subjs sets)
    train_mask = merged_global["subj_id"].isin(train_subjs)
    test_mask  = merged_global["subj_id"].isin(test_subjs)

    train_df = merged_global[train_mask].copy()
    test_df  = merged_global[test_mask].copy()

    # Ensure non-empty
    if train_df.shape[0] < 5 or test_df.shape[0] < 5:
        print("Too few rows after subject split. Skipping this n_feats.")
        continue

    # Encode labels (train only to avoid leakage in encoding)
    le = LabelEncoder()
    le.fit(train_df["label"].astype(str))
    y_train = le.transform(train_df["label"].astype(str))
    y_test  = le.transform(test_df["label"].astype(str))

    X_train = train_df[feat_cols].values.astype(float)
    X_test  = test_df[feat_cols].values.astype(float)

    # Standardize (fit on train, apply to test)
    sc = StandardScaler()
    X_train_s = sc.fit_transform(X_train)
    X_test_s  = sc.transform(X_test)

    # Fit & evaluate each model
    results = []
    for name, model in MODELS.items():
        try:
            m = model
            m.fit(X_train_s, y_train)
            yp = m.predict(X_test_s)
            acc = accuracy_score(y_test, yp)
            f1m = f1_score(y_test, yp, average="macro")
            f1w = f1_score(y_test, yp, average="weighted")
            rep = classification_report(y_test, yp, target_names=le.classes_)
            # save report + confusion matrix
            model_dir = run_out / name
            model_dir.mkdir(exist_ok=True, parents=True)
            with open(model_dir/"classification_report.txt","w") as fh:
                fh.write(rep)
            plot_and_save_cm(y_test, yp, le.classes_, model_dir/"confusion_matrix.png", f"{name} - {n_feats} per ch")
            results.append({
                "model": name, "accuracy": acc, "f1_macro": f1m, "f1_weighted": f1w,
                "report": str(model_dir/"classification_report.txt"),
                "confusion_matrix": str(model_dir/"confusion_matrix.png")
            })
            print(f"{name}: acc={acc:.4f}, f1m={f1m:.4f}")
        except Exception as e:
            print(f"Error training {name}: {e}")

    # Save summary csv for this n_feats
    res_df = pd.DataFrame(results).sort_values("accuracy", ascending=False)
    res_df.to_csv(run_out/"summary_results.csv", index=False)

    # Save best model summary (channel-agnostic)
    if not res_df.empty:
        best = res_df.iloc[0]
        summary_best.append({
            "n_feats_per_channel": n_feats,
            "best_model": best["model"],
            "accuracy": best["accuracy"]
        })
        # also save copy of best model report path
        (run_out/"best_model.txt").write_text(f"Best model: {best['model']}\nAccuracy: {best['accuracy']}\nReport: {best['report']}\nCM: {best['confusion_matrix']}\n")

# Final summary of best per n_feats
if summary_best:
    pd.DataFrame(summary_best).to_csv(OUT_MAIN_DIR/"best_model_summary_by_n_feats.csv", index=False)
    print("\nSaved best_model_summary_by_n_feats.csv")
else:
    print("No summaries produced.")
