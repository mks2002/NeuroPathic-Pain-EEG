import os
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    classification_report, confusion_matrix, f1_score, accuracy_score
)

# ---------------- Linear Models ----------------
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import SGDClassifier

# --------------- Tree-Based Models --------------
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

# ---------------- Boosting Models ----------------
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import AdaBoostClassifier

# XGBoost
from xgboost import XGBClassifier

# LightGBM
from lightgbm import LGBMClassifier

# ----------------- Other Models ------------------
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")


# ==========================================================
# CONFIG
# ==========================================================
BASE_DIR = Path("Merged_Features_AllMethods")
OUT_DIR = Path("ML_Model_Results_PerChannel")
OUT_DIR.mkdir(exist_ok=True, parents=True)

RANDOM_STATE = 42


# ==========================================================
# HELPER FUNCTIONS
# ==========================================================
def subject_stratified_split(df, subject_col="subj_id", label_col="label",test_size=0.2, random_state=42):

    subjects = df[[subject_col, label_col]].drop_duplicates()

    train_subj, test_subj = train_test_split(
        subjects,
        test_size=test_size,
        stratify=subjects[label_col],
        random_state=random_state
    )

    train_df = df[df[subject_col].isin(train_subj[subject_col])]
    test_df = df[df[subject_col].isin(test_subj[subject_col])]
    return train_df, test_df


def plot_confusion_matrix(y_true, y_pred, labels, out_path, title):
    cm = confusion_matrix(y_true, y_pred, labels=range(len(labels)))
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=labels, yticklabels=labels)
    plt.title(title)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()


def evaluate_model(model, X_train, X_test, y_train, y_test, label_encoder, model_name, save_dir):

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    model.fit(X_train_s, y_train)
    y_pred = model.predict(X_test_s)

    labels = list(label_encoder.classes_)
    acc = accuracy_score(y_test, y_pred)
    f1_macro = f1_score(y_test, y_pred, average="macro")
    f1_weighted = f1_score(y_test, y_pred, average="weighted")

    # Save Report
    report_path = save_dir / f"classification_report_{model_name}.txt"
    with open(report_path, "w") as f:
        f.write(classification_report(y_test, y_pred, target_names=labels))

    # Save Confusion Matrix
    cm_path = save_dir / f"confusion_matrix_{model_name}.png"
    plot_confusion_matrix(y_test, y_pred, labels, cm_path,
                          f"Confusion Matrix - {model_name}")

    return acc, f1_macro, str(report_path), str(cm_path)


# ==========================================================
# AVAILABLE MODELS
# ==========================================================
models = {
    # Linear Models
    "LogisticRegression": LogisticRegression(max_iter=2000, solver="liblinear", random_state=RANDOM_STATE),
    "SGDClassifier": SGDClassifier(loss="log_loss", max_iter=1000, random_state=RANDOM_STATE),

    # Tree-Based Models
    "DecisionTree": DecisionTreeClassifier(random_state=RANDOM_STATE),
    "RandomForest": RandomForestClassifier(n_estimators=100, random_state=RANDOM_STATE),

    # Boosting Models
    "GradientBoosting": GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=RANDOM_STATE),
    "AdaBoost": AdaBoostClassifier(n_estimators=50, learning_rate=1.0, random_state=RANDOM_STATE),
    "XGBoost": XGBClassifier(
        n_estimators=100, learning_rate=0.1, random_state=RANDOM_STATE,
        eval_metric="logloss", use_label_encoder=False
    ),
    "LGBM": LGBMClassifier(n_estimators=100, learning_rate=0.1, random_state=RANDOM_STATE),

    # Other Models
    "SVM": SVC(kernel="rbf", probability=True, random_state=RANDOM_STATE),
    "KNearestNeighbors": KNeighborsClassifier(n_neighbors=5),
    "NaiveBayes": GaussianNB(),
    "MLPClassifier": MLPClassifier(max_iter=500, random_state=RANDOM_STATE),
}


# ==========================================================
# MAIN LOOP — PER CHANNEL PIPELINE
# ==========================================================
summary_best_models = []

channel_files = sorted(list(BASE_DIR.glob("*_merged.csv")))

for ch_file in channel_files:
    channel = ch_file.stem.replace("_merged", "")
    print(f"\n\n====================== Channel: {channel} ======================")

    df = pd.read_csv(ch_file)

    # Encode labels
    le = LabelEncoder()
    df["y"] = le.fit_transform(df["label"].astype(str))

    # Split dataset subject-wise
    train_df, test_df = subject_stratified_split(df)

    X_train = train_df.drop(columns=["subj_id", "window_idx", "label", "y"])
    X_test = test_df.drop(columns=["subj_id", "window_idx", "label", "y"])
    y_train = train_df["y"]
    y_test = test_df["y"]

    # Create channel output folder
    channel_out = OUT_DIR / channel
    channel_out.mkdir(exist_ok=True, parents=True)

    # Record metrics for selecting best model
    results = []

    # Run all models
    for model_name, model in models.items():
        acc, f1_macro, rp, cm = evaluate_model(
            model, X_train, X_test, y_train, y_test, le, model_name, channel_out
        )

        results.append([model_name, acc, f1_macro, rp, cm])

    # Save results CSV
    res_df = pd.DataFrame(results, columns=[
        "model", "accuracy", "f1_macro", "report_path", "confusion_matrix_path"
    ])
    res_df.to_csv(channel_out / "results.csv", index=False)

    # Pick best model
    best_row = res_df.iloc[res_df["accuracy"].idxmax()]
    summary_best_models.append([channel, best_row["model"], best_row["accuracy"]])

    print(f"🔥 Best model for {channel}: {best_row['model']} (Acc={best_row['accuracy']:.4f})")


# ==========================================================
# SAVE OVERALL BEST MODEL SUMMARY
# ==========================================================
summary_df = pd.DataFrame(summary_best_models, 
                          columns=["channel", "best_model", "accuracy"])
summary_df.to_csv(OUT_DIR / "summary_best_models.csv", index=False)

print("\n\n==========================================")
print("   🎉 All Channels Processed Successfully!")
print("   Summary saved to summary_best_models.csv")
print("==========================================")
