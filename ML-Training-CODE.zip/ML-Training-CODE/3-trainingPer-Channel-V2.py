# Per-channel ML pipeline (subject-level split, stratified if possible)
# Saves per-channel model outputs and a master summary_best_models.csv
import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score

# Models
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

# ---------------- CONFIG ----------------
RANDOM_STATE = 42
BASE_MERGED_DIR = Path("Merged_Features_AllMethods")   # expects files like FP1_merged.csv, AFz_merged.csv, ...
OUT_MAIN_DIR = Path("ML_Model_Results_PerChannel")     # Option A structure
OUT_MAIN_DIR.mkdir(exist_ok=True, parents=True)

# Which columns are considered non-feature columns (will be preserved / removed automatically)
NON_FEATURE_COLS = ["subj_id", "window_idx", "label", "pain_score", "y"]

# Models to run (you can remove/add as desired)
models = {
    "LogisticRegression": LogisticRegression(max_iter=2000, solver="liblinear", random_state=RANDOM_STATE),
    "SGDClassifier": SGDClassifier(max_iter=2000, random_state=RANDOM_STATE),
    "DecisionTree": DecisionTreeClassifier(random_state=RANDOM_STATE),
    "RandomForest": RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE),
    "GradientBoosting": GradientBoostingClassifier(n_estimators=100, random_state=RANDOM_STATE),
    "AdaBoost": AdaBoostClassifier(n_estimators=50, random_state=RANDOM_STATE),
    "XGBoost": XGBClassifier(n_estimators=200, use_label_encoder=False, eval_metric="mlogloss", random_state=RANDOM_STATE),
    "LGBM": LGBMClassifier(n_estimators=200, random_state=RANDOM_STATE),
    "SVM": SVC(probability=True, random_state=RANDOM_STATE),
    "KNN": KNeighborsClassifier(n_neighbors=5),
    "NaiveBayes": GaussianNB(),
    "MLP": MLPClassifier(max_iter=500, random_state=RANDOM_STATE)
}

# ---------------- HELPERS ----------------
def subject_level_split(df, subject_col="subj_id", label_col="label", test_size=0.2, random_state=RANDOM_STATE):
    """
    Split subjects into train/test. Try to stratify on label (per-subject label).
    If stratify is not possible (some class has <2 subjects), fall back to random split.
    Returns train_df, test_df (dataframes of rows).
    """
    # get unique subjects and their label (one label per subj expected)
    subj_labels = df[[subject_col, label_col]].drop_duplicates().set_index(subject_col)[label_col]
    # drop subjects with missing labels
    subj_labels = subj_labels[~subj_labels.isna()]
    subjects = subj_labels.index.values
    labels = subj_labels.values

    # Check class counts per subject-level
    unique, counts = np.unique(labels, return_counts=True)
    class_counts = dict(zip(unique, counts))
    can_stratify = all(v >= 2 for v in class_counts.values())

    if can_stratify:
        try:
            train_subj, test_subj = train_test_split(
                subjects, test_size=test_size, random_state=random_state, stratify=labels
            )
        except Exception as e:
            # fallback
            train_subj, test_subj = train_test_split(subjects, test_size=test_size, random_state=random_state, shuffle=True)
            print("⚠️ Stratified split failed unexpectedly; did random split instead:", e)
    else:
        # warn and fallback to random split (stratification impossible)
        print(f"⚠️ Cannot stratify by subject-level label: class counts (per-subject) = {class_counts}. Doing random split instead.")
        train_subj, test_subj = train_test_split(subjects, test_size=test_size, random_state=random_state, shuffle=True)

    train_df = df[df[subject_col].isin(train_subj)]
    test_df = df[df[subject_col].isin(test_subj)]
    return train_df, test_df, subj_labels.to_dict()

def save_classification_report(report_txt, out_path):
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(report_txt)

def plot_and_save_cm(y_true, y_pred, labels_names, out_png_path, title="Confusion matrix"):
    cm = confusion_matrix(y_true, y_pred, labels=range(len(labels_names)))
    plt.figure(figsize=(6,5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=labels_names, yticklabels=labels_names)
    plt.title(title)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.tight_layout()
    plt.savefig(out_png_path)
    plt.close()

# ---------------- MAIN ----------------
summary_rows = []

merged_files = sorted([p for p in BASE_MERGED_DIR.glob("*_merged.csv")])
if not merged_files:
    raise SystemExit(f"No *_merged.csv found in {BASE_MERGED_DIR.resolve()}")

print(f"Found {len(merged_files)} merged channel files.")

for ch_file in merged_files:
    channel = ch_file.stem.replace("_merged", "")
    print(f"\n\n==================== CHANNEL: {channel} ====================")
    ch_out = OUT_MAIN_DIR / channel
    ch_out.mkdir(parents=True, exist_ok=True)

    # load
    df = pd.read_csv(ch_file)
    # Basic checks
    if "label" not in df.columns:
        print(f"⚠️ {ch_file.name} missing 'label' column — skipping channel.")
        continue
    if "subj_id" not in df.columns:
        print(f"⚠️ {ch_file.name} missing 'subj_id' column — skipping channel.")
        continue

    # Ensure one label per subject consistency (report if mismatch)
    subj_label_counts = df.groupby(["subj_id"])["label"].nunique()
    inconsistent_subj = subj_label_counts[subj_label_counts > 1].index.tolist()
    if inconsistent_subj:
        print(f"⚠️ Found subjects with >1 label in {channel}: {inconsistent_subj}. Using first label per subject for stratification.")

    # subject-level split
    train_df, test_df, subj_labels_map = subject_level_split(df, subject_col="subj_id", label_col="label", test_size=0.2, random_state=RANDOM_STATE)

    # Report subject counts per-class
    subj_label_ser = pd.Series(subj_labels_map)
    subj_dist = subj_label_ser.value_counts().to_dict()
    print("Subject-level distribution (per-class):", subj_dist)

    if train_df.shape[0] == 0 or test_df.shape[0] == 0:
        print(f"⚠️ Train or test is empty for channel {channel}: train={train_df.shape}, test={test_df.shape}. Skipping.")
        continue

    # Build X, y
    feature_cols = [c for c in df.columns if c not in NON_FEATURE_COLS]
    if len(feature_cols) == 0:
        print(f"⚠️ No feature columns found in {ch_file.name} (after removing {NON_FEATURE_COLS}). Skipping.")
        continue

    X_train = train_df[feature_cols].values
    X_test = test_df[feature_cols].values
    y_train_labels = train_df["label"].values
    y_test_labels = test_df["label"].values

    # encode labels (global for this channel)
    le = LabelEncoder()
    le.fit(pd.concat([train_df["label"], test_df["label"]]).astype(str))
    y_train = le.transform(y_train_labels)
    y_test = le.transform(y_test_labels)
    label_names = list(le.classes_)
    print("Classes:", label_names)

    # Clean NaN/Inf using column-wise strategy with training set statistics only (no leakage)
    # Replace training NaNs by column means computed on training set; same mapping applied to test.
    col_means = np.nanmean(X_train, axis=0)
    col_means = np.where(np.isnan(col_means), 0.0, col_means)

    inds_train = np.where(np.isnan(X_train))
    if inds_train[0].size:
        X_train[inds_train] = np.take(col_means, inds_train[1])
    X_train = np.nan_to_num(X_train, posinf=0.0, neginf=0.0)

    # apply same filling to test
    inds_test = np.where(np.isnan(X_test))
    if inds_test[0].size:
        X_test[inds_test] = np.take(col_means, inds_test[1])
    X_test = np.nan_to_num(X_test, posinf=0.0, neginf=0.0)

    # standardize (fit scaler on train only)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # For recording per-model results
    channel_results = []

    for model_name, model in models.items():
        try:
            print(f" → Training {model_name} ...", end=" ")
            # clone model to avoid state carryover (simple re-init by constructing new from class)
            # but as we stored model instances above, we will create a fresh one via repr/constructor mapping.
            # Simpler: just re-create by name from models dict type
            base = models[model_name]
            # instantiate a fresh model (works for sklearn estimators and xgboost, lightgbm)
            fresh_model = None
            try:
                # attempt to call class with same __dict__ params
                cls = base.__class__
                fresh_model = cls(**{k: v for k, v in base.get_params().items() if k in cls().get_params()})
            except Exception:
                # fallback: use the original instance (should be ok but risk re-fit side-effects)
                fresh_model = base.__class__(**base.get_params())

            fresh_model.random_state = getattr(base, "random_state", RANDOM_STATE)

            # fit and predict
            fresh_model.fit(X_train_scaled, y_train)
            y_pred = fresh_model.predict(X_test_scaled)

            acc = accuracy_score(y_test, y_pred)
            f1_macro = f1_score(y_test, y_pred, average="macro")
            f1_weighted = f1_score(y_test, y_pred, average="weighted")

            # prepare paths
            report_txt = classification_report(y_test, y_pred, target_names=label_names)
            report_path = ch_out / f"classification_report_{model_name}.txt"
            cm_path = ch_out / f"confusion_matrix_{model_name}.png"

            # save results
            save_classification_report(report_txt, report_path)
            plot_and_save_cm(y_test, y_pred, label_names, cm_path, title=f"{channel} - {model_name}")

            channel_results.append({
                "model": model_name,
                "accuracy": float(acc),
                "f1_macro": float(f1_macro),
                "f1_weighted": float(f1_weighted),
                "report_path": str(report_path),
                "confusion_matrix_path": str(cm_path)
            })
            print(f"done (acc={acc:.3f})")
        except Exception as e:
            print(f"ERROR training {model_name} on {channel}: {e}")
            continue

    # save per-channel results.csv
    results_df = pd.DataFrame(channel_results).sort_values("accuracy", ascending=False)
    results_df.to_csv(ch_out / "results.csv", index=False)

    # pick best model by accuracy
    if not results_df.empty:
        best_row = results_df.iloc[0]
        summary_rows.append({
            "channel": channel,
            "best_model": best_row["model"],
            "best_accuracy": float(best_row["accuracy"])
        })
        print(f"🔥 Best model for {channel}: {best_row['model']} (Acc={best_row['accuracy']:.4f})")
    else:
        print(f"⚠️ No successful models for channel {channel}")

# write master summary
summary_df = pd.DataFrame(summary_rows)
summary_df.to_csv(OUT_MAIN_DIR / "summary_best_models.csv", index=False)
print("\nAll channels processed. Summary saved to:", (OUT_MAIN_DIR / "summary_best_models.csv").resolve())
