# ================================================
# MULTI-CHANNEL FUSION PIPELINE (NO LEAKAGE)
# Loads features from SELECTED CHANNELS,
# merges horizontally, applies subject-level
# train/test split, trains all models,
# saves classification reports + CMs.
# ================================================

import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score

# Models
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier


# --------------------------------------------------
# CONFIG
# --------------------------------------------------
RANDOM_STATE = 42
BASE_DIR = Path("Merged_Features_AllMethods")
OUT_DIR = Path("ML_Model_Results_Final")
OUT_DIR.mkdir(parents=True, exist_ok=True)

# <=== EDIT THIS LIST FOR ANY CHANNEL COMBINATION ===>
CHANNEL_GROUP = ["FP1", "F3", "Pz", "AFz"]  # example


NON_FEATURE_COLS = ["subj_id", "window_idx", "label", "pain_score", "y"]

MODELS = {
    "LogisticRegression": LogisticRegression(max_iter=2000, solver="liblinear"),
    "SGDClassifier": SGDClassifier(max_iter=2000),
    "DecisionTree": DecisionTreeClassifier(),
    "RandomForest": RandomForestClassifier(n_estimators=200),
    "GradientBoosting": GradientBoostingClassifier(),
    "AdaBoost": AdaBoostClassifier(),
    "XGBoost": XGBClassifier(n_estimators=200, use_label_encoder=False, eval_metric="mlogloss"),
    "LGBM": LGBMClassifier(n_estimators=200),
    "SVM": SVC(probability=True),
    "KNN": KNeighborsClassifier(n_neighbors=5),
    "NaiveBayes": GaussianNB(),
    "MLP": MLPClassifier(max_iter=500)
}

for k in MODELS:
    if hasattr(MODELS[k], "random_state"):
        MODELS[k].random_state = RANDOM_STATE


# --------------------------------------------------
# FUNCTIONS
# --------------------------------------------------
def subject_level_split(df):
    subj_labels = df[["subj_id", "label"]].drop_duplicates()
    subj_labels = subj_labels[~subj_labels["label"].isna()]
    subjects = subj_labels["subj_id"].values
    labels = subj_labels["label"].values

    # try stratified split
    unique, counts = np.unique(labels, return_counts=True)
    if np.all(counts >= 2):
        train_subj, test_subj = train_test_split(
            subjects, test_size=0.2, stratify=labels,
            random_state=RANDOM_STATE
        )
    else:
        print("⚠️ Cannot stratify, doing random split.")
        train_subj, test_subj = train_test_split(
            subjects, test_size=0.2, random_state=RANDOM_STATE
        )

    train_df = df[df["subj_id"].isin(train_subj)]
    test_df = df[df["subj_id"].isin(test_subj)]
    return train_df, test_df


def plot_cm(y_true, y_pred, labels, save_path, title):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6,5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=labels, yticklabels=labels)
    plt.title(title)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


# --------------------------------------------------
# LOAD AND MERGE SELECTED CHANNELS
# --------------------------------------------------
# --------------------------------------------------
# LOAD AND MERGE SELECTED CHANNELS (FIXED)
# --------------------------------------------------
dfs = []
print("\n=== Loading Selected Channels ===")
for ch in CHANNEL_GROUP:
    f = BASE_DIR / f"{ch}_merged.csv"
    if not f.exists():
        print(f"❌ MISSING: {f}")
        continue

    print(f"Loaded: {f.name}")
    df = pd.read_csv(f)

    # DROP duplicate non-feature columns that cause merge conflicts
    for col in ["pain_score"]:
        if col in df.columns:
            df = df.drop(columns=[col])

    dfs.append(df)

if len(dfs) == 0:
    raise SystemExit("No channel files loaded. Check CHANNEL_GROUP.")


print("\nMerging channels...")
merged = dfs[0]

for d in dfs[1:]:
    # Also drop any leftover *_x, *_y from previous merges
    cols_to_drop = [c for c in d.columns if c.endswith("_x") or c.endswith("_y")]
    if cols_to_drop:
        d = d.drop(columns=cols_to_drop)

    merged = pd.merge(
        merged, d,
        on=["subj_id", "window_idx", "label"],
        how="inner",
        suffixes=(None, None)
    )

print("Final merged shape:", merged.shape)



# --------------------------------------------------
# SUBJECT-LEVEL SPLIT
# --------------------------------------------------
train_df, test_df = subject_level_split(merged)
print("Train rows:", train_df.shape[0], " Test rows:", test_df.shape[0])

# --------------------------------------------------
# Prepare matrices
# --------------------------------------------------

label_encoder = LabelEncoder()
label_encoder.fit(pd.concat([train_df["label"], test_df["label"]]).astype(str))
y_train = label_encoder.transform(train_df["label"])
y_test  = label_encoder.transform(test_df["label"])
labels = list(label_encoder.classes_)

feature_cols = [c for c in merged.columns if c not in NON_FEATURE_COLS]

X_train = train_df[feature_cols].values
X_test  = test_df[feature_cols].values

# Clean NaN/Inf
col_means = np.nanmean(X_train, axis=0)
col_means = np.where(np.isnan(col_means), 0.0, col_means)

inds_train = np.where(np.isnan(X_train))
if inds_train[0].size:
    X_train[inds_train] = np.take(col_means, inds_train[1])

inds_test = np.where(np.isnan(X_test))
if inds_test[0].size:
    X_test[inds_test] = np.take(col_means, inds_test[1])

X_train = np.nan_to_num(X_train, posinf=0, neginf=0)
X_test = np.nan_to_num(X_test, posinf=0, neginf=0)

# Scale
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)


# --------------------------------------------------
# RUN ALL MODELS
# --------------------------------------------------
results = []

for model_name, model in MODELS.items():
    print(f"\n▶ Training {model_name}...")

    clf = model.__class__(**model.get_params())
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    f1m = f1_score(y_test, y_pred, average="macro")

    # save report
    report = classification_report(y_test, y_pred, target_names=labels)
    with open(OUT_DIR / f"classification_report_{model_name}.txt", "w") as f:
        f.write(report)

    # save confusion matrix
    plot_cm(
        y_test, y_pred, labels,
        OUT_DIR / f"confusion_matrix_{model_name}.png",
        f"{model_name} (Channels: {CHANNEL_GROUP})"
    )

    print(f"   Accuracy = {acc:.4f}, Macro-F1 = {f1m:.4f}")
    results.append([model_name, acc, f1m])

# save summary
pd.DataFrame(results, columns=["model", "accuracy", "macro_f1"]).to_csv(
    OUT_DIR / "results.csv", index=False
)

print("\n🎉 FINISHED! Results saved in:", OUT_DIR.resolve())
print("Channels used =", CHANNEL_GROUP)
